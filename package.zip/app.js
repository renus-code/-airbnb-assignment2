const express = require("express");
const path = require("path");
const { engine } = require("express-handlebars");

const app = express();
const port = process.env.PORT || 3000;

// Serve static files from "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Set up Handlebars as the view engine
app.engine(".hbs", engine({ extname: ".hbs" }));
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "views"));

// Home route
app.get("/", (req, res) => {
  res.render("index", { title: "Express Handlebars Example" });
});

// Example route for /users
app.get("/users", (req, res) => {
  res.send("Respond with a resource");
});

// Catch-all route for invalid URLs
app.all(/.*/, (req, res) => {
  res.status(404).render("error", {
    title: "Error",
    message: "Wrong Route",
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
